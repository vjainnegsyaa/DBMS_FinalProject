CREATE DATABASE car_rental;
USE car_rental;

-- Create member Table
CREATE TABLE member(
	member_id INT(11) AUTO_INCREMENT PRIMARY KEY,
	google_id VARCHAR(50) NOT NULL,
	gmail VARCHAR(255) NOT NULL,
	phone VARCHAR(10) NOT NULL,
	CONSTRAINT chk_gmail CHECK (gmail REGEXP '^[a-zA-Z0-9._%+-]{6,30}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'),
    CONSTRAINT chk_phone CHECK (phone REGEXP '^09[0-9]{8}$')
);

-- Create location  Table
CREATE TABLE location (
    loc_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    loc_name VARCHAR(15) NOT NULL,
    city VARCHAR(15) NOT NULL,
    district VARCHAR(15) NOT NULL,
    address VARCHAR(50) NOT NULL
);

-- Create insurance Table
CREATE TABLE insurance(
    insurance_id INT(11) AUTO_INCREMENT PRIMARY KEY ,
    ins_name VARCHAR(20) NOT NULL,
    coverage VARCHAR(255) NOT NULL,
    ins_fee INT(4) NOT NULL CHECK (ins_fee >= 0)
);

-- Create model Table
CREATE TABLE model(
	model_id INT(11) AUTO_INCREMENT PRIMARY KEY,
	brand VARCHAR(30) NOT NULL,
	model_name VARCHAR(30) NOT NULL,
	car_type VARCHAR(10) NOT NULL CHECK (car_type IN ('Compact', 'Sedan', 'SUV', 'MPV')),
	fuel_type VARCHAR(10) NOT NULL CHECK (fuel_type IN ('Gasoline', 'Electric', 'Hybrid')),
	engine_cc INT(5) NOT NULL CHECK (engine_cc >= 0),
	transmission INT(1) NOT NULL,
	image_url VARCHAR(100) NOT NULL
);

-- Create car Table
CREATE TABLE car (
    car_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    vin VARCHAR(50) NOT NULL,
    plate_number VARCHAR(8) NOT NULL CHECK (plate_number REGEXP '^R[A-Z]{2}-[0-9]{4}$'),
    daily_fee INT(5) NOT NULL CHECK (daily_fee >= 0),
    late_fee INT(4) NOT NULL CHECK (late_fee >= 0),
    year_made INT(4) NOT NULL CHECK (year_made >= 1980),
    seat_num INT(2) NOT NULL CHECK (seat_num > 0),
    color VARCHAR(20) NOT NULL,
    mileage INT(6) NOT NULL CHECK (mileage > 0),
    car_status ENUM('available', 'maintenance', 'disable') NOT NULL DEFAULT 'available',
    notes TEXT,
    model_id INT NOT NULL,
    loc_id INT,
    FOREIGN KEY (model_id) REFERENCES model(model_id) 
    	ON DELETE NO ACTION,
    FOREIGN KEY (loc_id) REFERENCES location(loc_id) 
    	ON DELETE SET NULL
);

-- Create rental Table
CREATE TABLE rental (
    rental_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    actual_return DATETIME,
    created_at DATETIME NOT NULL,
    rental_status ENUM('pending','active','completed','cancelled','reject') NOT NULL DEFAULT 'pending',
    amount INT(7) NOT NULL CHECK (amount >= 0),
    payment_date DATETIME,
    method ENUM('cash', 'credit', 'linepay') NOT NULL,
    member_id INT(11) NOT NULL,
    car_id INT(11) NOT NULL,
    pickup_loc INT(11) NOT NULL,
    drop_loc INT(11) NOT NULL,
    insurance_id INT(11) NOT NULL,
    CONSTRAINT fk_member_id FOREIGN KEY (member_id) REFERENCES member(member_id)
    	ON DELETE CASCADE,
    CONSTRAINT fk_car_id FOREIGN KEY (car_id) REFERENCES car(car_id)
    	ON DELETE NO ACTION,
    CONSTRAINT fk_pickup_loc FOREIGN KEY (pickup_loc) REFERENCES location(loc_id) 
    	ON DELETE NO ACTION,
    CONSTRAINT fk_drop_loc FOREIGN KEY (drop_loc) REFERENCES location(loc_id) 
    	ON DELETE NO ACTION,
    CONSTRAINT fk_insurance_id FOREIGN KEY (insurance_id) REFERENCES insurance(insurance_id) 
    	ON DELETE NO ACTION
);
ALTER TABLE rental
    ADD COLUMN payment_status INT NOT NULL DEFAULT 0 CHECK (payment_status IN (0, 1));
    



USE car_rental;

-- INSERT member Table
INSERT INTO member (member_id, google_id, gmail, phone) VALUES
(1, '879012345678901234567', 'quincy_liu@gmail.com', '0978999000'),
(2, '657890123456789012345', 'kulpia@gmail.com', '0978985123'),
(3, '111996782304424104647', 'gene_st@gmail.com', '0914238500'),
(4, '192703829478239801723', 'Wen_Che@gmail.com', '0932535148'),
(5, '215784230947120938765', 'asd_tw@gmail.com', '0931164655'),
(6, '342057390258473869423', 'kevin_jj@gmail.com', '0923969027'),
(7, '102345678901234567890', 'jane_liu@gmail.com', '0999000111'),
(8, '213456789012345678901', 'kevin_liu@yahoo.com', '0912333444'),
(9, '324567890123456789012', 'lisa_wang@nfu.edu.tw', '0923444555'),
(10, '435678901234567890123', 'mike_smith@wistron.com', '0934555666'),
(11, '546789012345678901234', 'nancy_johnson@foxconn.com', '0945666777'),
(12, '567890123456789012345', 'ethan.lu@yahoo.com', '0944555666'),
(13, '678901234567890123456', 'fiona.lee@nfu.edu.tw', '0955666777'),
(14, '789012345678901234567', 'george.lin@gmail.com', '0966777888'),
(15, '123456789012345678901', 'alice_wu@gmail.com', '0987123456');

-- INSERT location Data
INSERT INTO location (loc_id, loc_name, city, district, address) VALUES
(1, '雲林縣虎尾店', '雲林縣', '虎尾鎮', '文化路64號'),
(2, '雲林縣斗六店', '雲林縣', '斗六市', '大學路三段123號'),
(3, '嘉義市東區店', '嘉義市', '東區', '學府路300號'),
(4, '嘉義縣民雄店', '嘉義縣', '民雄鄉', '神農路145號'),
(5, '雲林縣斗南店', '雲林縣', '斗南鎮', '大業路106號'),
(6, '台中市霧峰店', '台中市', '霧峰區', '吉峰東路168號'),
(7, '台中市南屯店', '台中市', '南屯區', '大墩路200號'),
(8, '台北市信義店', '台北市', '信義區', '松山路100號'),
(9, '新北市板橋店', '新北市', '板橋區', '文化路二段50號'),
(10, '高雄市苓雅店', '高雄市', '苓雅區', '和平一路300號'),
(11, '高雄市前鎮店', '高雄市', '前鎮區', '中華五路88號'),
(12, '台南市東區店', '台南市', '東區', '大學路100號'),
(13, '台南市北區店', '台南市', '北區', '成功路200號'),
(14, '新竹市東區店', '新竹市', '東區', '光復路一段150號'),
(15, '桃園市中壢店', '桃園市', '中壢區', '中正路300號');

-- INSERT insurance Data
INSERT INTO insurance (insurance_id, ins_name, coverage, ins_fee) VALUES
(1, '基本保險方案', '第三人責任保險：每人傷害上限200萬、每事故傷害上限400萬、財損上限50萬。駕駛人保險100萬、乘客每人100萬（超載除外）。', 0),
(2, '第三人責任升級', '每人傷害上限提升至500萬、每事故傷害1000萬、財損上限200萬。其餘條件比照基本方案。', 200),
(3, '第三人責任與車體損害升級版', '每人傷害上限提升至500萬、每事故傷害1000萬、財損上限200萬。其餘規定比照基本保險。', 400),
(4, '豪華第三人責任險', '每人傷害上限800萬、每事故傷害1500萬、財損上限300萬，乘客保險每人200萬。不含車體損害。', 600),
(5, '全方位保險方案', '涵蓋第三人責任升級版保障，並新增車體損失險（含碰撞、自撞、翻車、他人肇逃）、竊盜險。自負額每次事故5000元。', 800),
(6, '高階全險(免自負額)', '等同全方位保險方案，另提供不限事故次數之免自負額保障。亦納入每日車輛停駛補償保險。', 1400),
(7, '節能保險方案', '提供基本保險保障，專為電動車設計，另含電池損害與火災保險（限電動車適用）。', 100),
(8, '超級全險（海外人士專用）', '提供全方位保險保障，另納入外籍駕駛法律援助保險與語言協助。', 1600),
(9, '商務菁英保險方案', '含高階全險保障，另增加行程延誤補償與駕駛更換服務，每日最高補償3000元。', 1800),
(10, '至尊全險方案', '含所有前述保險保障，另提供不限次數道路救援、全天候代步車服務、全額車損理賠（免自負額）。', 2500);

-- INSERT model Data
INSERT INTO model (model_id, brand, model_name, car_type, fuel_type, engine_cc, transmission, image_url) VALUES
(1, 'TOYOTA', 'Altis 12', 'Compact', 'Hybrid', 1800, 1, 'img/Altis12.jpg'),
(2, 'HONDA', 'Odyssey 2019', 'MPV', 'Gasoline', 2500, 1, 'img/Odyssey12.jpg'),
(3, 'TESLA', 'Model 3', 'Sedan', 'Electric', 0, 1, 'img/model3.jpg'),
(4, 'TOYOTA', 'RAV4 2022', 'SUV', 'Hybrid', 2500, 1, 'img/rav4_2022.jpg'),
(5, 'MITSUBISHI', 'Grand Lancer', 'Compact', 'Gasoline', 1500, 1, 'img/glancer.jpg'),
(6, 'FORD', 'Focus 2018', 'Compact', 'Gasoline', 1600, 1, 'img/focus_2018.jpg'),
(7, 'HYUNDAI', 'Tucson 2020', 'SUV', 'Gasoline', 2000, 1, 'img/tucson_2020.jpg'),
(8, 'NISSAN', 'Leaf 2021', 'Compact', 'Electric', 0, 1, 'img/leaf_2021.jpg'),
(9, 'KIA', 'Seltos 2022', 'SUV', 'Gasoline', 1600, 1, 'img/seltos_2022.jpg'),
(10, 'CMC', 'JSPACE', 'MPV', 'Gasoline', 1500, 0, 'img/CMC_JSPACE.jpg');

-- INSERT car Data
INSERT INTO car (car_id, vin, plate_number, model_id, daily_fee, late_fee, year_made, loc_id, seat_num, color, mileage, notes, car_status) VALUES
(1, '4T1BE46KX7U123456', 'RAA-7777', 1, 1800, 200, 2020, 1, 5, '白色', 15000, '可以隨心所欲', 'available'),  -- Altis12
(2, '4T1BE46KXPX123789', 'RAA-8888', 1, 1800, 200, 2020, 2, 5, '白色', 16500, '可以隨心所欲', 'available'),  -- Altis12
(3, '5FNRL38647B654321', 'RAR-2385', 2, 2200, 200, 2020, 1, 7, '黑色', 12000, '座椅舒適，適合家庭出遊', 'available'),  -- Odyssey 2019
(4, '5YJ3E1EA7KF123456', 'REK-3556', 3, 2500, 300, 2021, 10, 5, '銀色', 8000, '行駛安靜', 'available'),  -- TESLA
(5, '4T3HV36KXPX456781', 'RBC-8811', 4, 2200, 300, 2022, 1, 5, '白色', 7500, '可以隨心所欲SUV', 'available'),  -- RAV4 2022
(6, '4T3HV36KXPX456782', 'RBC-9922', 4, 2200, 300, 2022, 3, 5, '白色', 9200, '可以隨心所欲SUV', 'maintenance'),  -- RAV4 2022
(7, 'JMBGR31L6JU123456', 'RAF-5678', 5, 1700, 200, 2019, 1, 5, '黑色', 15000, '內裝整潔，冷氣超強', 'available'),  -- Grand Lancer
(8, '1FADP3F2XJL123456', 'RBC-1234', 6, 1800, 200, 2018, 8, 5, '銀色', 18000, '油耗低', 'maintenance'),  -- Focus 2018
(9, 'KM8K6CA43LU123456', 'RBD-4567', 7, 2000, 250, 2020, 6, 5, '黑色', 5000, '空間寬敞', 'available'),  -- Tucson 2020
(10, '1N4A11APXJC12389', 'RBD-6789', 8, 1800, 200, 2021, 7, 5, '綠色', 3000, '行駛安靜', 'available'),  -- Leaf 2021
(11, '1N4A11APXJC123456', 'RBD-6789', 8, 1800, 200, 2021, 7, 5, '綠色', 3000, '行駛安靜', 'disable'),  -- Leaf 2021
(12, 'KNDJ23AU7L121621', 'RBD-2345', 9, 1800, 200, 2022, 4, 5, '藍色', 4000, '小巧靈活，適合城市駕駛', 'disable'),  -- Seltos 2022
(13, 'KNDJ23AU7L1234567', 'RBD-2345', 9, 1800, 200, 2022, 8, 5, '藍色', 4000, '小巧靈活，適合城市駕駛', 'disable'),  -- Seltos 2022
(14, 'CMBJ1234567890123', 'RAS-1234', 10, 1700, 200, 2019, 6, 8, '白色', 8000, '空間大，適合家庭出遊', 'available')  -- CMC JSPACE
(15, 'CMBJ1234567890124', 'RAS-5678', 10, 1700, 200, 2019, 5, 8, '白色', 5500, '空間大，適合家庭出遊', 'available');  -- CMC JSPACE

-- INSERT rental Data
INSERT INTO rental (rental_id, start_date, end_date, actual_return, created_at, rental_status,amount, payment_date, method, member_id, car_id, pickup_loc,drop_loc,insurance_id, payment_status) VALUES
(1, '2025-06-02 08:00:00', '2025-06-05 17:00:00', NULL, '2025-06-01 13:09:21', 'reject', 8000, NULL, 'cash', 1, 1, 1, 1, 2, 0),
(2, '2025-06-13 08:00:00', '2025-06-14 17:00:00', NULL, '2025-06-01 13:25:08', 'cancelled', 6400, NULL, 'cash', 1, 1, 1, 1, 6, 0),
(3, '2025-07-14 11:05:00', '2025-07-17 23:45:00', NULL, '2025-06-01 13:39:19', 'active', 12400, NULL, 'cash', 2, 15, 5, 5, 6, 0),
(4, '2025-06-18 13:10:00', '2025-06-20 00:40:00', '2025-06-20 00:30:00', '2025-06-14 18:59:20', 'completed', 5200, '2025-06-15 19:25:00', 'linepay', 4, 4, 10, 10, 7, 1),
(5, '2025-07-11 21:30:00', '2025-07-13 21:00:00', NULL, '2025-07-08 19:22:26', 'active', 4400, '2025-07-08 21:52:34', 'credit', 3, 10, 7, 7, 3, 1),
(6, '2025-06-23 09:30:00', '2025-06-27 18:00:00', '2025-06-27 17:55:00', '2025-06-01 13:44:58', 'completed', 10000, '2025-06-23 09:20:00', 'cash', 7, 9, 6, 4, 1, 1),
(7, '2025-07-12 07:30:00', '2025-07-13 20:00:00', NULL, '2025-06-01 13:45:39', 'cancelled', 5200, NULL, 'cash', 8, 9, 6, 6, 4, 0),
(8, '2025-06-02 06:03:00', '2025-06-04 19:05:00', NULL, '2025-06-01 13:46:28', 'cancelled', 7800, NULL, 'cash', 9, 5, 10, 1, 3, 0),
(9, '2025-06-07 20:00:00', '2025-06-10 19:05:00', '2025-06-10 19:08:00', '2025-06-01 13:47:35', 'completed', 10800, '2025-06-07 19:45:30', 'cash', 10, 1, 1, 2, 9, 1),
(10, '2025-06-19 05:00:00', '2025-06-19 23:00:00', NULL, '2025-06-01 13:50:43', 'active', 3800, NULL, 'cash', 8, 3, 1, 1, 8, 0),
(11, '2025-07-15 07:03:00', '2025-07-18 16:06:00', NULL, '2025-06-01 13:51:33', 'active', 18800, NULL, 'cash', 8, 3, 1, 7, 10, 0);
