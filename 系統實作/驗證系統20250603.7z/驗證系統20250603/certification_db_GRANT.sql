CREATE USER 'ad_python'@'localhost' IDENTIFIED BY 'ad_python';
GRANT SELECT,UPDATE ON certification_db.users TO 'ad_python'@'localhost';
-- SHOW GRANTS FOR 'ad_python'@'localhost';