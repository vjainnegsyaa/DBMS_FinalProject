from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, get_jwt, decode_token
from datetime import timedelta
import pymysql
import hashlib

app = Flask(__name__)

# 設定 JWT
app.config["JWT_SECRET_KEY"] = "TESTER"
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=1)
jwt = JWTManager(app)

# 黑名單
blacklist = set()

# 連接 MySQL
db = pymysql.connect(
    host="localhost",
    user="ad_python",
    password="ad_python",
    database="certification_db",
    cursorclass=pymysql.cursors.DictCursor
)

@app.route("/admin/login", methods=["POST"])
def admin_login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "帳號或密碼錯誤"}), 404

    # 使用 SHA-256 加密密碼來比對
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    with db.cursor() as cursor:
        sql = "SELECT * FROM users WHERE BINARY username = %s AND password = %s AND role = 'admin'"
        cursor.execute(sql, (username, password_hash))
        admin = cursor.fetchone()
    if not admin:
        return jsonify({"error": "帳號或密碼錯誤"}), 404

    # 生成 JWT
    access_token = create_access_token(identity=admin["username"], additional_claims={"role": admin["role"]})

    # 使用 decode_token 取得 jti
    decoded_token = decode_token(access_token)
    jti = decoded_token["jti"]

    # 存入資料庫
    with db.cursor() as cursor:
        sql = "UPDATE users SET current_jti = %s WHERE username = %s"
        cursor.execute(sql, (jti, username))
        db.commit()

    return jsonify({"message": "登入成功", "access_token": access_token}), 200

@jwt.token_in_blocklist_loader
def check_if_token_in_blacklist(jwt_header, jwt_payload):
    jti = jwt_payload["jti"]
    return jti in blacklist

@app.route("/admin/logout", methods=["POST"])
@jwt_required()
def logout():
    jti = get_jwt()["jti"]
    identity = get_jwt_identity()

    # 清除資料庫中的 jti
    with db.cursor() as cursor:
        sql = "UPDATE users SET current_jti = NULL WHERE username = %s"
        cursor.execute(sql, (identity,))
        db.commit()

    blacklist.add(jti)  # 加入黑名單
    return jsonify({"message": "成功登出"}), 200

@app.route("/admin/verify", methods=["GET"])
@jwt_required()
def verify_token():
    try:
        identity = get_jwt_identity()  # 取得 token 內的使用者名稱
        jti = get_jwt()["jti"]  # 取得當前 token 的 jti

        # 檢查資料庫連線是否有效
        if db.open:
            with db.cursor() as cursor:
                cursor.execute("SELECT current_jti FROM users WHERE username = %s", (identity,))
                user = cursor.fetchone()

                if user:
                    db_jti = user["current_jti"]
                    if jti == db_jti:
                        return jsonify({"message": "驗證成功"}), 200
                    else:
                        return jsonify({"error": "驗證失敗"}), 404 #"Token 不匹配
                else:
                    return jsonify({"error": "驗證失敗"}), 404 #無此使用者
        else:
            return jsonify({"error": "驗證失敗"}), 500  #資料庫連線失敗
    except:
        return jsonify({"error":"驗證失敗"}), 500  #異常錯誤


if __name__ == "__main__":
    app.run(debug=True)
