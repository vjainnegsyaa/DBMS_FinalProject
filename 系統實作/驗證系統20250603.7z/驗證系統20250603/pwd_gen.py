import hashlib
if __name__ == "__main__":
    password = input("Please input PWD:")
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    print(password_hash)